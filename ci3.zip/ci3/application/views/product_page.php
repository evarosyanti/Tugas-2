<html>
<head>
    <title>Product Page</title>
</head>
<body>
    <h1>Ini adalah halaman Product</h1>
</body>
</html>